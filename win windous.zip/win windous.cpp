﻿#define _WIN32_WINNT 0x0501
#include <windows.h>
#include <psapi.h>
#include <tchar.h>
#include <stdio.h>
#include <shellapi.h> 

#pragma comment(lib, "psapi.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "advapi32.lib") 

// --- 全局变量 ---
BOOL isDragging = FALSE;
HCURSOR hCursorCross;
HCURSOR hCursorNormal;
RECT rectDragBtn = { 50, 60, 250, 110 }; // 居中拖拽区

// --- 1. 自动提权逻辑 (已修复崩溃问题) ---
BOOL IsRunAsAdmin() {
    BOOL fIsRunAsAdmin = FALSE;
    PSID pAdminSID = NULL;

    // 关键修复：必须定义此结构体，不能传 NULL
    SID_IDENTIFIER_AUTHORITY NtAuthority = SECURITY_NT_AUTHORITY;

    if (AllocateAndInitializeSid(&NtAuthority, 2, SECURITY_BUILTIN_DOMAIN_RID,
        DOMAIN_ALIAS_RID_ADMINS, 0, 0, 0, 0, 0, 0, &pAdminSID)) {

        if (!CheckTokenMembership(NULL, pAdminSID, &fIsRunAsAdmin)) {
            fIsRunAsAdmin = FALSE;
        }
        FreeSid(pAdminSID);
    }
    return fIsRunAsAdmin;
}

// 如果不是管理员，则尝试以管理员身份重启自己
void GainAdminPrivileges(HINSTANCE hInstance, int nCmdShow) {
    if (IsRunAsAdmin()) return; // 已经是管理员，直接返回

    TCHAR szPath[MAX_PATH];
    if (GetModuleFileName(NULL, szPath, ARRAYSIZE(szPath))) {
        SHELLEXECUTEINFO sei = { sizeof(sei) };
        sei.cbSize = sizeof(sei); // 修正：最好显式设置大小
        sei.lpVerb = _T("runas"); // 关键：请求提升权限
        sei.lpFile = szPath;
        sei.hwnd = NULL;
        sei.nShow = nCmdShow;

        if (ShellExecuteEx(&sei)) {
            ExitProcess(0); // 启动新进程成功，旧进程退出
        }
        else {
            // 用户点了“否”或者提权失败，依然继续运行，但可能无法获取部分路径
            MessageBox(NULL, _T("未能获取管理员权限，部分系统进程路径可能无法探测。"), _T("提示"), MB_ICONWARNING);
        }
    }
}

// --- 2. 核心业务逻辑 ---

// 打开文件夹并选中文件
void OpenFileInExplorer(const TCHAR* path) {
    if (!path || _tcslen(path) == 0) return;

    TCHAR param[MAX_PATH + 20];
    // 使用 /select 参数来高亮选中文件
    _stprintf_s(param, _T("/select,\"%s\""), path);
    ShellExecute(NULL, _T("open"), _T("explorer.exe"), param, NULL, SW_SHOW);
}

// 获取窗口信息并弹窗
void CaptureWindowInfo(HWND hWndPoint) {
    if (hWndPoint == NULL) return;

    DWORD processID;
    GetWindowThreadProcessId(hWndPoint, &processID);

    TCHAR processPath[MAX_PATH] = _T("");
    BOOL bSuccess = FALSE;

    HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, processID);
    if (hProcess != NULL) {
        if (GetModuleFileNameEx(hProcess, NULL, processPath, MAX_PATH) != 0) {
            bSuccess = TRUE;
        }
        CloseHandle(hProcess);
    }

    TCHAR msg[1024];
    if (bSuccess) {
        _stprintf_s(msg, 1024,
            _T("捕获成功！\n\n")
            _T("进程 ID (PID): %d\n")
            _T("文件路径: %s\n\n")
            _T("是否打开文件所在位置？"),
            processID, processPath
        );

        // MB_YESNO: 这里的 YES 会在左边
        int result = MessageBox(NULL, msg, _T("探测完成"), MB_YESNO | MB_ICONQUESTION | MB_TOPMOST);

        if (result == IDYES) {
            OpenFileInExplorer(processPath);
        }
    }
    else {
        _stprintf_s(msg, 1024, _T("捕获到了窗口 (PID: %d)，但无法读取路径。\n可能对方是受保护的系统进程。"), processID);
        MessageBox(NULL, msg, _T("提示"), MB_OK | MB_ICONWARNING);
    }
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
    case WM_CREATE:
        hCursorCross = LoadCursor(NULL, IDC_CROSS);
        hCursorNormal = LoadCursor(NULL, IDC_ARROW);
        break;

    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);

        HBRUSH hBrush = CreateSolidBrush(RGB(240, 240, 240));
        FillRect(hdc, &rectDragBtn, hBrush);
        DeleteObject(hBrush);
        FrameRect(hdc, &rectDragBtn, (HBRUSH)GetStockObject(BLACK_BRUSH));

        SetBkMode(hdc, TRANSPARENT);
        DrawText(hdc, _T("✖ 按住这里拖拽到目标"), -1, &rectDragBtn, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

        RECT rectTip = { 0, 140, 300, 180 };
        SetTextColor(hdc, RGB(100, 100, 100));
        // 根据当前是否是管理员显示不同提示
        if (IsRunAsAdmin()) {
            DrawText(hdc, _T("已启用管理员模式\n可探测高权限程序"), -1, &rectTip, DT_CENTER | DT_VCENTER);
        }
        else {
            DrawText(hdc, _T("普通用户模式\n(部分程序可能无法探测)"), -1, &rectTip, DT_CENTER | DT_VCENTER);
        }

        EndPaint(hWnd, &ps);
    }
    break;

    case WM_LBUTTONDOWN:
    {
        POINT pt = { LOWORD(lParam), HIWORD(lParam) };
        if (PtInRect(&rectDragBtn, pt)) {
            isDragging = TRUE;
            SetCapture(hWnd);
            SetCursor(hCursorCross);
        }
    }
    break;

    case WM_MOUSEMOVE:
        if (isDragging) {
            SetCursor(hCursorCross);
        }
        break;

    case WM_LBUTTONUP:
        if (isDragging) {
            isDragging = FALSE;
            ReleaseCapture();
            SetCursor(hCursorNormal);

            POINT ptScreen;
            GetCursorPos(&ptScreen);
            HWND hWndPoint = WindowFromPoint(ptScreen);

            if (hWndPoint != hWnd) {
                CaptureWindowInfo(hWndPoint);
            }
        }
        break;

    case WM_DESTROY:
        PostQuitMessage(0);
        break;

    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    // 检查提权
    GainAdminPrivileges(hInstance, nCmdShow);

    WNDCLASSEX wcex = { 0 };
    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndProc;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wcex.lpszClassName = _T("SpyToolAdminFixed");

    if (!RegisterClassEx(&wcex)) return 1;

    HWND hWnd = CreateWindow(
        _T("SpyToolAdminFixed"),
        _T("强力窗口探测器 (Fix)"),
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        CW_USEDEFAULT, CW_USEDEFAULT, 320, 220,
        NULL, NULL, hInstance, NULL
    );

    if (!hWnd) return 1;

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return (int)msg.wParam;
}